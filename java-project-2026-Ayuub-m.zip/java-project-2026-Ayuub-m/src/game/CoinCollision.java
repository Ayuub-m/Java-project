package game;

import city.cs.engine.*;


/**
 * Coin Collision - handles what happens when the player touches the coin
 * implement CollisionListener to check for collisons
 */

public class CoinCollision implements CollisionListener {

    private Player player;

    /**
     * constructor -  links to the player
     */

    public CoinCollision(Player player) {
        this.player = player;
    }

    /**
     * called when two bodies collide with each other
     */

    @Override
    public void collide(CollisionEvent e) {
        //check if the player hit the coin
        if (e.getOtherBody() instanceof Coin) {
            // Remove the coin from the world
            e.getOtherBody().destroy();

            //Add points to score e.g.5 points
            player.addScore(5);
        }
    }
}
