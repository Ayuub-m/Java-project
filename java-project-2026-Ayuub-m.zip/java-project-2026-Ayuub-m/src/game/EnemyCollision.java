package game;

import city.cs.engine.*;

/**
 * This is the EnemyCollison class - handles what happens when a player touches an enemy
 * player should lose health
 */

public class EnemyCollision implements CollisionListener {

    private Player player;

    /**
     * A constructor - links to the player
     */

    public EnemyCollision(Player player) {
        this.player = player;
    }

    /**
     * Called when two objects/bodies collide
     */
    @Override
    public void collide(CollisionEvent e) {
        //Checks if the player hit an enemy
        if (e.getOtherBody() instanceof Enemy) {
            // lower the players health e.g.10
            player.loseHealth(10);
        }
    }
}
