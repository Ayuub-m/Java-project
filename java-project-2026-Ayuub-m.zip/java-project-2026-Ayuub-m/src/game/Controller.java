package game;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

/**
 * this is a controller class - handles all the keyboard inputs
 * checks for the arrow keys to move the player
 */

public class Controller implements KeyListener {

    private Player player;

    /**
     * constructor - links controller to the player
     */

    public Controller(Player player) {
        this.player = player;
    }

    /**
     * called when an arrow key is pressed
     */

    @Override
    public void keyPressed(KeyEvent e) {
        int code = e.getKeyCode();

        //left arrow - walk left
        if (code == KeyEvent.VK_LEFT) {
            player.startWalking(-5);
        }
        //right arrow - walk right
        if (code == KeyEvent.VK_RIGHT) {
            player.startWalking(5);
        }
        //up arrow - jump
        if (code == KeyEvent.VK_UP) {
            player.jump(10);
        }
    }

    /**
     * called when a key is released
     */
    @Override
    public void keyReleased(KeyEvent e) {
        // stop walking when any arrow key is released
        player.stopWalking();
    }

        /**
         * not used but required by KeyListener interface
         */
        @Override
        public void keyTyped(KeyEvent e){
    }

}
