package game;

import city.cs.engine.*;
import city.cs.engine.Shape;
import org.jbox2d.common.Vec2;

import javax.swing.JFrame;

import java.awt.*;
import java.io.IOException;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;

/**
 * Your main game entry point
 */
public class Game {


    /** Initialise a new Game. */
    public Game() {

        //1. create a game world
        GameWorld world = new GameWorld();

        //2. Get the player from the world so we can pass it to the GameView
        Player player = world.getPlayer();


        //3. create a view with health/score display
        GameView view = new GameView(world, 500, 500, player);


        //optional: draw a 1-metre grid over the view
        // view.setGridResolution(1);


        //4. create a Java window (frame) and add the game
        //   view to it
        final JFrame frame = new JFrame("City Game");
        frame.add(view);

        // enable the frame to quit the application
        // when the x button is pressed
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationByPlatform(true);
        // don't let the frame be resized
        frame.setResizable(false);
        // size the frame to fit the world view
        frame.pack();
        // finally, make the frame visible
        frame.setVisible(true);




        //create controller and connect it to player
        Controller controller = new Controller(player);

        // Make the view listen to the keyboard input
        view.addKeyListener(controller);
        view.requestFocus();

        //Start the physics simulation
        world.start();

        //optional: uncomment this to make a debugging view
         //JFrame debugView = new DebugViewer(world, 500, 500);

    }

    /** Run the game. */
    public static void main(String[] args) {

        new Game();
    }
}
