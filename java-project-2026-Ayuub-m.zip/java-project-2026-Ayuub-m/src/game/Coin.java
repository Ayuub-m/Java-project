package game;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;

/**
 * This is the coin class - These will give the character points
 * Extends StaticBody so the coin stays in place
 */

public class Coin extends StaticBody {

    /**
     *  A constructor - creates a coin
     */

    public Coin(World world) {
        //Create a coin with a small circle shape
        super(world, new CircleShape(0.5f));

        //Add coin image
        addImage(new BodyImage("data/books.png", 1f));
    }
}
