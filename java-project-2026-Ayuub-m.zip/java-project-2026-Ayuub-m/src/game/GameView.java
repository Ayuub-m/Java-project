package game;

import city.cs.engine.UserView;
import java.awt.*;

/**
 * This is the GameView - a custom view that displays in the game world
 * shows the players score and health on the screen rather than in the terminal
 */

public class GameView extends UserView {

    private  Player player;

    /**
     * A constructor - this creates the view
     */

    public GameView(GameWorld world, int width, int height, Player player) {
        super(world, width, height);
        this.player = player;
    }

    /**
     * Put score and health on the top
     */

    @Override
    protected void paintForeground(Graphics2D g) {
        // Set text color and font
        g.setColor(Color.BLACK);
        g.setFont(new Font("Arial", Font.BOLD, 20));

        //put score in top left
        g.drawString("Score: " + player.getScore(), 20, 30);

        // put health in top left below score
        g.drawString("Health: " + player.getHealth(), 20, 60);
    }
}
