package game;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;

/**
 * This is the enemy class - the character that will try to hurt the player
 * I Extend walker so it can move
 */

public class Enemy extends Walker {

    /**
     * A constructor - creates the enemey
     */

    public Enemy(World world) {
        //Create an enemy with a box shape
        super(world, new BoxShape(0.8f, 1.5f));

        // Add an image for it
        addImage(new BodyImage("data/student.png", 3f));

        //Make the enemy walk left automatically
        startWalking(-3);
    }
}
