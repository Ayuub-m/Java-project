package game;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;
import java.awt.Color;

/**
 * This is my GameWorld class - it contains all the games objects(players platoforms etc.)
 * Extends the world from the physics engine
 * using inheritance because GameWorld is a world within the game
 */

public class GameWorld extends World {

    private Player player;

    /**
     * This is a constructor - it sets up the game world
     */

    public GameWorld() {
        // Call parent world contrusctor
        super();

        //make a ground platform
        Shape shape = new BoxShape(30, 0.5f);
        // this is in the game world so i changed to *this*.
        StaticBody ground = new StaticBody(this, shape);
        ground.setPosition(new Vec2(0f, -11.5f));
        ground.setFillColor(Color.BLUE);

        // make a suspended platform
        Shape platformShape = new BoxShape(3, 0.5f);
        StaticBody platform1 = new StaticBody(this, platformShape);
        platform1.setPosition(new Vec2(-8, -4f));

        //make a character (with an overlaid image)
        player = new Player(this);
        player.setPosition(new Vec2(4, -5));

        // connect collision listener to player
        CoinCollision coinListener = new CoinCollision(player);
        player.addCollisionListener(coinListener);

        //Connect enemy CollisonListner
        EnemyCollision enemyListener = new EnemyCollision(player);
        player.addCollisionListener(enemyListener);

        //Create some coins to collect
        Coin coin1 = new Coin(this);
        coin1.setPosition(new Vec2(-5, -3));

        Coin coin2 = new Coin(this);
        coin2.setPosition(new Vec2(2, -10));

        Coin coin3 = new Coin(this);
        coin3.setPosition(new Vec2(-10, -10));

        Enemy enemy = new Enemy(this);
        enemy.setPosition(new Vec2(-5, -10));
    }

    /**
     * Get the player from this world
     */
    public Player getPlayer() {
        return player;
    }
}
