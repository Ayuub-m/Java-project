package game;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;

/**
 * This is the player class - this will be the main character of the game
 * Extends walker so that the character can walk and jump
 */

public class Player extends Walker {

    private int score = 0;
    private int health = 100;

    /**
     * This is a constructor - it creates the player with a 1x2 box shape
     */

    public Player(World world) {
        // Call the Walker constructor with a 1x2 box shape
        super(world, new BoxShape(1, 2));

        //Add the student image
        addImage(new BodyImage("data/student.png", 4));
    }

    /**
     * Add points to score when collecting coins
     */
    public void addScore(int points) {
        score = score + points;
        System.out.println("Score: " + score); //Print to console for now
    }

    /**
     * Get Current Score
     */
    public int getScore() {

        return score;
    }

    /**
     * lower health when enemy hits
     */

    public void loseHealth(int damage) {
        health = health - damage;

        // dont let health go below zero
        if (health < 0) {
            health = 0;
        }

        System.out.println("Health: " + health);

        // check if the player is out of health/dead
        if (health <= 0) {
            System.out.println("Game Over!");
        }
    }


    /**
     * this gets the current health
     */
    public int getHealth() {
        return health;
    }
}
